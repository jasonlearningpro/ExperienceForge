// 3D model viewer: puts a 3D model (.glb from Blender, or .stl) on a screen, drawn with plain WebGL.
// It needs two permissions: to use the course's files (the model) and to put its own code in the courses you publish.
// What it reads: a .glb (glTF 2.0 binary) with its shapes, node placements and each part's base color; an .stl (binary or text).
// What it leaves out: pictures on the model (textures), animation, compression (Draco, meshopt) and lights from the file.
// The learner can turn the model by dragging, with buttons, or with the arrow keys; it can also turn slowly by itself (off by default), with a Pause button.
window.kfPlugins = (window.kfPlugins || []).concat([{
  manifest: { id: 'experienceforge.model-viewer', name: '3D model viewer', version: '1.1.0', apiVersion: 1, capabilities: ['read-assets', 'adds-code-to-exports'] },
  activate: function (api) {
    var TYPE = 'experienceforge.model';
    var RULE = 'experienceforge.model-described';
    var MAX_TRIANGLES = 1500000;

    // ---------- small matrix helpers (column-major 4x4, as WebGL wants) ----------
    function ident() { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
    function mul(a, b) {
      var o = new Array(16);
      for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
      return o;
    }
    function translate(x, y, z) { var m = ident(); m[12] = x; m[13] = y; m[14] = z; return m; }
    function scale(s) { var m = ident(); m[0] = s; m[5] = s; m[10] = s; return m; }
    function rotX(a) { var c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]; }
    function rotY(a) { var c = Math.cos(a), s = Math.sin(a); return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]; }
    function perspective(fov, aspect, near, far) {
      var f = 1 / Math.tan(fov / 2);
      return [f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, (2 * far * near) / (near - far), 0];
    }
    function fromTrs(t, q, s) {
      var x = q[0], y = q[1], z = q[2], w = q[3];
      var x2 = x + x, y2 = y + y, z2 = z + z;
      var xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2;
      return [
        (1 - (yy + zz)) * s[0], (xy + wz) * s[0], (xz - wy) * s[0], 0,
        (xy - wz) * s[1], (1 - (xx + zz)) * s[1], (yz + wx) * s[1], 0,
        (xz + wy) * s[2], (yz - wx) * s[2], (1 - (xx + yy)) * s[2], 0,
        t[0], t[1], t[2], 1
      ];
    }
    function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }

    // ---------- reading a model: both kinds become "batches" of flat triangles ----------
    // A batch: { pos: Float32Array (x,y,z per corner), nor: Float32Array, color: [r,g,b] or null }
    function latin1(bytes, from, to) {
      var out = '';
      for (var i = from; i < to; i += 8192) out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(to, i + 8192)));
      return out;
    }
    function flatNormals(pos) {
      var nor = new Float32Array(pos.length);
      for (var i = 0; i < pos.length; i += 9) {
        var ax = pos[i + 3] - pos[i], ay = pos[i + 4] - pos[i + 1], az = pos[i + 5] - pos[i + 2];
        var bx = pos[i + 6] - pos[i], by = pos[i + 7] - pos[i + 1], bz = pos[i + 8] - pos[i + 2];
        var nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        var l = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
        for (var k = 0; k < 3; k++) { nor[i + k * 3] = nx / l; nor[i + k * 3 + 1] = ny / l; nor[i + k * 3 + 2] = nz / l; }
      }
      return nor;
    }
    function parseStl(bytes) {
      var pos;
      var dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      var n = bytes.length >= 84 ? dv.getUint32(80, true) : -1;
      if (n >= 0 && 84 + n * 50 === bytes.length) {
        if (n > MAX_TRIANGLES) throw new Error('too many triangles');
        pos = new Float32Array(n * 9);
        for (var t = 0; t < n; t++) {
          var base = 84 + t * 50 + 12;
          for (var k = 0; k < 9; k++) pos[t * 9 + k] = dv.getFloat32(base + k * 4, true);
        }
      } else {
        var text = latin1(bytes, 0, bytes.length);
        var re = /vertex\s+(\S+)\s+(\S+)\s+(\S+)/g;
        var list = [];
        var m;
        while ((m = re.exec(text))) { list.push(parseFloat(m[1]), parseFloat(m[2]), parseFloat(m[3])); if (list.length > MAX_TRIANGLES * 9) throw new Error('too many triangles'); }
        if (list.length < 9 || list.length % 9 !== 0) throw new Error('no triangles');
        pos = new Float32Array(list);
      }
      for (var i = 0; i < pos.length; i += 3) { var y = pos[i + 1]; pos[i + 1] = pos[i + 2]; pos[i + 2] = -y; } // an STL has Z up; the viewer has Y up
      return [{ pos: pos, nor: flatNormals(pos), color: null }];
    }

    function parseGlb(bytes) {
      var dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      var jsonLen = dv.getUint32(12, true);
      var json = JSON.parse(latin1(bytes, 20, 20 + jsonLen));
      var binStart = 20 + jsonLen + 8;
      if (20 + jsonLen + 8 > bytes.length || dv.getUint32(20 + jsonLen + 4, true) !== 0x004e4942) throw new Error('no data');
      var binLen = dv.getUint32(20 + jsonLen, true);
      var bin = new DataView(bytes.buffer, bytes.byteOffset + binStart, Math.min(binLen, bytes.length - binStart));
      var COMPS = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
      function read(index) {
        var acc = (json.accessors || [])[index];
        if (!acc || acc.sparse || acc.bufferView === undefined) throw new Error('unsupported data');
        var view = json.bufferViews[acc.bufferView];
        var comps = COMPS[acc.type];
        if (!comps || view.buffer !== 0) throw new Error('unsupported data');
        var size = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 }[acc.componentType];
        if (!size) throw new Error('unsupported data');
        var stride = view.byteStride || comps * size;
        var start = (view.byteOffset || 0) + (acc.byteOffset || 0);
        if (acc.count > MAX_TRIANGLES * 3 || start + (acc.count - 1) * stride + comps * size > bin.byteLength) throw new Error('damaged data');
        var out = acc.componentType === 5126 ? new Float32Array(acc.count * comps) : new Uint32Array(acc.count * comps);
        for (var i = 0; i < acc.count; i++) for (var c = 0; c < comps; c++) {
          var at = start + i * stride + c * size, v;
          switch (acc.componentType) {
            case 5126: v = bin.getFloat32(at, true); break;
            case 5125: v = bin.getUint32(at, true); break;
            case 5123: v = bin.getUint16(at, true); break;
            case 5122: v = bin.getInt16(at, true); break;
            case 5121: v = bin.getUint8(at); break;
            default: v = bin.getInt8(at);
          }
          out[i * comps + c] = v;
        }
        return out;
      }
      var batches = [];
      var triangles = 0;
      function addMesh(mesh, m) {
        (mesh.primitives || []).forEach(function (p) {
          if ((p.mode !== undefined && p.mode !== 4) || !p.attributes || p.attributes.POSITION === undefined) return;
          var P = read(p.attributes.POSITION);
          var N = p.attributes.NORMAL !== undefined ? read(p.attributes.NORMAL) : null;
          var idx = p.indices !== undefined ? read(p.indices) : null;
          var count = idx ? idx.length : P.length / 3;
          count -= count % 3;
          triangles += count / 3;
          if (triangles > MAX_TRIANGLES) throw new Error('too many triangles');
          var pos = new Float32Array(count * 3);
          var nor = new Float32Array(count * 3);
          for (var i = 0; i < count; i++) {
            var v = idx ? idx[i] : i;
            if (v * 3 + 2 >= P.length) throw new Error('damaged data');
            var x = P[v * 3], y = P[v * 3 + 1], z = P[v * 3 + 2];
            pos[i * 3] = m[0] * x + m[4] * y + m[8] * z + m[12];
            pos[i * 3 + 1] = m[1] * x + m[5] * y + m[9] * z + m[13];
            pos[i * 3 + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
            if (N) {
              var nx = N[v * 3], ny = N[v * 3 + 1], nz = N[v * 3 + 2];
              var ox = m[0] * nx + m[4] * ny + m[8] * nz, oy = m[1] * nx + m[5] * ny + m[9] * nz, oz = m[2] * nx + m[6] * ny + m[10] * nz;
              var l = Math.sqrt(ox * ox + oy * oy + oz * oz) || 1;
              nor[i * 3] = ox / l; nor[i * 3 + 1] = oy / l; nor[i * 3 + 2] = oz / l;
            }
          }
          var color = null;
          var mat = p.material !== undefined ? (json.materials || [])[p.material] : null;
          if (mat) {
            var f = mat.pbrMetallicRoughness && mat.pbrMetallicRoughness.baseColorFactor;
            color = f ? [num(f[0], 1), num(f[1], 1), num(f[2], 1)] : [1, 1, 1];
          }
          batches.push({ pos: pos, nor: N ? nor : flatNormals(pos), color: color });
        });
      }
      var nodes = json.nodes || [];
      function visit(i, parent, depth) {
        var node = nodes[i];
        if (!node || depth > 64) return;
        var local = node.matrix && node.matrix.length === 16 ? node.matrix
          : fromTrs(node.translation || [0, 0, 0], node.rotation || [0, 0, 0, 1], node.scale || [1, 1, 1]);
        var m = mul(parent, local);
        if (node.mesh !== undefined && json.meshes && json.meshes[node.mesh]) addMesh(json.meshes[node.mesh], m);
        (node.children || []).forEach(function (c) { visit(c, m, depth + 1); });
      }
      var scene = json.scenes && json.scenes[json.scene || 0];
      if (scene && scene.nodes) scene.nodes.forEach(function (n) { visit(n, ident(), 0); });
      else nodes.forEach(function (n, i) { if (n.mesh !== undefined) visit(i, ident(), 0); });
      if (!batches.length) throw new Error('no shapes');
      return batches;
    }

    /** Reads a model's bytes into batches and finds its middle and size (a sphere around all of it). */
    function parseModel(bytes) {
      var isGlb = bytes.length > 4 && bytes[0] === 0x67 && bytes[1] === 0x6c && bytes[2] === 0x54 && bytes[3] === 0x46;
      var batches = isGlb ? parseGlb(bytes) : parseStl(bytes);
      var lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
      batches.forEach(function (b) {
        for (var i = 0; i < b.pos.length; i += 3) for (var k = 0; k < 3; k++) { var v = b.pos[i + k]; if (v < lo[k]) lo[k] = v; if (v > hi[k]) hi[k] = v; }
      });
      var c = [(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2];
      var r = 0;
      batches.forEach(function (b) {
        for (var i = 0; i < b.pos.length; i += 3) {
          var dx = b.pos[i] - c[0], dy = b.pos[i + 1] - c[1], dz = b.pos[i + 2] - c[2];
          var d = dx * dx + dy * dy + dz * dz;
          if (d > r) r = d;
        }
      });
      return { batches: batches, center: c, radius: Math.sqrt(r) || 1 };
    }

    // ---------- drawing with WebGL ----------
    var VERT = 'attribute vec3 aPos; attribute vec3 aNor; uniform mat4 uMvp; uniform mat3 uRot; varying vec3 vN; void main() { vN = uRot * aNor; gl_Position = uMvp * vec4(aPos, 1.0); }';
    var FRAG = 'precision mediump float; varying vec3 vN; uniform vec3 uColor; void main() { vec3 n = normalize(vN); float key = abs(dot(n, normalize(vec3(0.4, 0.6, 0.7)))); float fill = abs(dot(n, normalize(vec3(-0.6, -0.2, 0.5)))); float l = 0.28 + 0.62 * key + 0.18 * fill; gl_FragColor = vec4(uColor * min(l, 1.0), 1.0); }';

    function makeDrawer(canvas, model, color) {
      var gl = canvas.getContext('webgl', { antialias: true, alpha: true, premultipliedAlpha: true });
      if (!gl) return null;
      function shader(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; }
      var prog = gl.createProgram();
      gl.attachShader(prog, shader(gl.VERTEX_SHADER, VERT));
      gl.attachShader(prog, shader(gl.FRAGMENT_SHADER, FRAG));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return null;
      gl.useProgram(prog);
      var aPos = gl.getAttribLocation(prog, 'aPos'), aNor = gl.getAttribLocation(prog, 'aNor');
      var uMvp = gl.getUniformLocation(prog, 'uMvp'), uRot = gl.getUniformLocation(prog, 'uRot'), uColor = gl.getUniformLocation(prog, 'uColor');
      var parts = model.batches.map(function (b) {
        var p = gl.createBuffer(), n = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, p); gl.bufferData(gl.ARRAY_BUFFER, b.pos, gl.STATIC_DRAW);
        gl.bindBuffer(gl.ARRAY_BUFFER, n); gl.bufferData(gl.ARRAY_BUFFER, b.nor, gl.STATIC_DRAW);
        return { p: p, n: n, count: b.pos.length / 3, color: b.color || color };
      });
      gl.enable(gl.DEPTH_TEST);
      return {
        draw: function (view) {
          var w = canvas.width, h = canvas.height;
          gl.viewport(0, 0, w, h);
          gl.clearColor(0, 0, 0, 0);
          gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
          var aspect = w / Math.max(1, h);
          var fit = Math.min(1, aspect) * 0.92;
          var turn = view.turn * Math.PI / 180, tilt = view.tilt * Math.PI / 180;
          var rot = mul(rotX(tilt), rotY(turn));
          var local = mul(scale(fit * view.zoom / model.radius), translate(-model.center[0], -model.center[1], -model.center[2]));
          var mv = mul(translate(0, 0, -3.4), mul(rot, local));
          var mvp = mul(perspective(35 * Math.PI / 180, aspect, 0.1, 30), mv);
          gl.uniformMatrix4fv(uMvp, false, new Float32Array(mvp));
          gl.uniformMatrix3fv(uRot, false, new Float32Array([rot[0], rot[1], rot[2], rot[4], rot[5], rot[6], rot[8], rot[9], rot[10]]));
          parts.forEach(function (part) {
            gl.uniform3f(uColor, part.color[0], part.color[1], part.color[2]);
            gl.bindBuffer(gl.ARRAY_BUFFER, part.p); gl.enableVertexAttribArray(aPos); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
            gl.bindBuffer(gl.ARRAY_BUFFER, part.n); gl.enableVertexAttribArray(aNor); gl.vertexAttribPointer(aNor, 3, gl.FLOAT, false, 0, 0);
            gl.drawArrays(gl.TRIANGLES, 0, part.count);
          });
        },
        dispose: function () { var x = gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); }
      };
    }

    function hexToRgb(hex, fallback) {
      var m = /^#([0-9a-fA-F]{6})$/.exec(typeof hex === 'string' ? hex : '');
      if (!m) return fallback;
      var n = parseInt(m[1], 16);
      return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
    }

    // ---------- the item ----------
    var parsed = {};   // asset id -> Promise of the read model (kept so a redraw does not read it again)
    var views = {};    // item id -> how the learner last left it
    var live = {};     // item id -> the drawer now on the page, so a redraw lets go of the old one

    api.stage.addElement({
      type: TYPE, label: '3D model', icon: '3D', idPrefix: 'mdl', size: { w: 420, h: 360 },
      settings: [
        { kind: 'asset', key: 'model', label: '3D model (glb or stl)', default: '', assetKind: 'model', help: 'Bring one in with Import 3D model on the Assets tab.' },
        { kind: 'text', key: 'description', label: 'Description for screen readers', default: '', maxLength: 300, multiline: true, help: 'Say what the model shows, such as "A red gearbox seen from the front".' },
        { kind: 'color', key: 'color', label: 'Color (for a model with no color of its own, such as an STL)', default: '#8fa3ba' },
        { kind: 'number', key: 'startTurn', label: 'Starting turn', default: 30, min: -180, max: 180, unit: 'degrees' },
        { kind: 'number', key: 'startTilt', label: 'Starting tilt', default: 15, min: -80, max: 80, unit: 'degrees' },
        { kind: 'boolean', key: 'drag', label: 'The learner can turn it by dragging', default: true },
        { kind: 'boolean', key: 'buttons', label: 'Show buttons to turn, tilt and zoom', default: true },
        { kind: 'boolean', key: 'autoRotate', label: 'Turn slowly by itself (a Pause button is added)', default: false }
      ],
      create: function (id) { return { id: id, type: TYPE }; },
      summary: function (el) { return (el.data && el.data.description) || '3D model'; },
      render: function (el, ctx) {
        var s = ctx.settings;
        var doc = ctx.doc;
        var pal = ctx.look.palette;
        var interactive = ctx.mode === 'play';
        var root = doc.createElement('div');
        root.style.cssText = 'width:100%;height:100%;display:flex;flex-direction:column;box-sizing:border-box;gap:6px;position:relative;' + (interactive ? '' : 'pointer-events:none;');
        var name = s.description ? String(s.description) : '3D model';
        root.setAttribute('role', 'group');
        root.setAttribute('aria-label', name);
        if (interactive) root.tabIndex = 0;

        var stageBox = doc.createElement('div');
        stageBox.style.cssText = 'flex:1 1 0;min-height:0;position:relative;';
        var canvas = doc.createElement('canvas');
        var W = Math.max(64, Math.min(1600, Math.round(num(el.w, 420) * 1.5)));
        var H = Math.max(64, Math.min(1600, Math.round(Math.max(48, num(el.h, 360) - ((s.buttons || s.autoRotate) ? 42 : 0)) * 1.5)));
        canvas.width = W; canvas.height = H;
        canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block;touch-action:pan-y;' + (s.drag && interactive ? 'cursor:grab;' : '');
        canvas.setAttribute('role', 'img');
        canvas.setAttribute('aria-label', name + (s.drag ? '. Drag to turn it.' : ''));
        var note = doc.createElement('div');
        note.setAttribute('role', 'status');
        note.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;padding:8px;box-sizing:border-box;color:' + pal.text + ';';
        note.textContent = s.model ? 'Loading the 3D model…' : 'Choose a 3D model in Properties.';
        stageBox.appendChild(canvas);
        stageBox.appendChild(note);
        root.appendChild(stageBox);

        // Turning by itself: only in the course (not while editing), slow, stopped by the learner's own moves, and still for a device that asks for less motion.
        var autoOn = !!s.autoRotate && interactive;
        var reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
        var view = views[el.id] || { turn: num(s.startTurn, 30), tilt: num(s.startTilt, 15), zoom: 1, paused: reduce };
        views[el.id] = view;
        var drawer = null;
        var raf = 0, lastT = 0, seen = false;
        var pauseBtn = null;
        function playing() { return autoOn && !view.paused; }
        function redraw() { if (drawer) drawer.draw(view); }
        function syncPause() {
          if (!pauseBtn) return;
          var label = playing() ? 'Pause turning' : 'Turn by itself';
          pauseBtn.textContent = playing() ? '⏸ Pause' : '▶ Turn';
          pauseBtn.setAttribute('aria-label', label);
          pauseBtn.title = label;
        }
        function tick(t) {
          raf = 0;
          if (!playing() || !drawer || live[el.id] !== drawer) return;
          if (root.isConnected) seen = true; else if (seen) return;
          if (lastT && root.isConnected) view.turn = ((view.turn + (t - lastT) * 0.012 + 540) % 360) - 180;
          lastT = t;
          redraw();
          raf = requestAnimationFrame(tick);
        }
        function startAuto() { if (playing() && drawer && !raf) { lastT = 0; raf = requestAnimationFrame(tick); } }
        function takeOver() { if (autoOn && !view.paused) { view.paused = true; syncPause(); } }
        function change(dTurn, dTilt, zoomBy) {
          takeOver();
          view.turn = ((view.turn + dTurn + 540) % 360) - 180;
          view.tilt = Math.max(-89, Math.min(89, view.tilt + dTilt));
          view.zoom = Math.max(0.4, Math.min(3, view.zoom * zoomBy));
          redraw();
        }
        function reset() { takeOver(); view.turn = num(s.startTurn, 30); view.tilt = num(s.startTilt, 15); view.zoom = 1; redraw(); }

        if (s.buttons || autoOn) {
          var bar = doc.createElement('div');
          bar.setAttribute('role', 'group');
          bar.setAttribute('aria-label', '3D model controls');
          bar.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;justify-content:center;flex:none;';
          var list = [];
          if (autoOn) list.push(['', 'Pause turning', function () { view.paused = !view.paused; syncPause(); if (playing()) startAuto(); }]);
          if (s.buttons) {
            list.push(['◀', 'Turn left', function () { change(-15, 0, 1); }], ['▶', 'Turn right', function () { change(15, 0, 1); }],
              ['▲', 'Tilt up', function () { change(0, 10, 1); }], ['▼', 'Tilt down', function () { change(0, -10, 1); }],
              ['+', 'Zoom in', function () { change(0, 0, 1.25); }], ['−', 'Zoom out', function () { change(0, 0, 0.8); }],
              ['Reset', 'Reset the view', reset]);
          }
          list.forEach(function (b, i) {
            var btn = doc.createElement('button');
            btn.type = 'button';
            btn.textContent = b[0];
            btn.setAttribute('aria-label', b[1]);
            btn.title = b[1];
            btn.style.cssText = 'min-width:36px;height:36px;padding:0 10px;border-radius:8px;border:1px solid ' + pal.text + ';background:' + pal.surface + ';color:' + pal.text + ';font:inherit;cursor:pointer;';
            btn.addEventListener('click', b[2]);
            if (autoOn && i === 0) pauseBtn = btn;
            bar.appendChild(btn);
          });
          syncPause();
          root.appendChild(bar);
        }

        if (interactive) {
          root.addEventListener('keydown', function (e) {
            var k = e.key, used = true;
            if (k === 'ArrowLeft') change(-10, 0, 1); else if (k === 'ArrowRight') change(10, 0, 1);
            else if (k === 'ArrowUp') change(0, 8, 1); else if (k === 'ArrowDown') change(0, -8, 1);
            else if (k === '+' || k === '=') change(0, 0, 1.2); else if (k === '-' || k === '_') change(0, 0, 0.83);
            else if (k === 'Home') reset(); else used = false;
            if (used) e.preventDefault();
          });
          if (s.drag) {
            var last = null;
            canvas.addEventListener('pointerdown', function (e) { takeOver(); last = { x: e.clientX, y: e.clientY }; canvas.style.cursor = 'grabbing'; if (canvas.setPointerCapture) { try { canvas.setPointerCapture(e.pointerId); } catch (x) { /* not capturable */ } } });
            canvas.addEventListener('pointermove', function (e) { if (!last) return; var dx = e.clientX - last.x, dy = e.clientY - last.y; last = { x: e.clientX, y: e.clientY }; change(dx * 0.6, dy * 0.6, 1); });
            var end = function () { last = null; canvas.style.cursor = 'grab'; };
            canvas.addEventListener('pointerup', end);
            canvas.addEventListener('pointercancel', end);
          }
        }

        if (!s.model) return root;
        if (live[el.id]) { live[el.id].dispose(); delete live[el.id]; }
        var wanted = s.model;
        if (!parsed[wanted]) {
          parsed[wanted] = ctx.assetBytes(wanted).then(function (bytes) {
            if (!bytes) throw new Error('missing');
            return parseModel(bytes);
          });
        }
        parsed[wanted].then(function (model) {
          drawer = makeDrawer(canvas, model, hexToRgb(s.color, [0.56, 0.64, 0.73]));
          if (!drawer) { note.textContent = 'This device cannot show 3D models.'; return; }
          live[el.id] = drawer;
          note.style.display = 'none';
          redraw();
          startAuto();
        }, function () {
          delete parsed[wanted];
          note.textContent = 'The 3D model could not be shown.';
        });
        return root;
      }
    });

    api.validation.addRule({
      id: RULE,
      label: '3D models are described',
      check: function (project) {
        var found = [];
        var have = {};
        (project.assets || []).forEach(function (a) { have[a.id] = true; });
        (project.nodes || []).forEach(function (n) {
          if (n.type !== 'screenNode' || !n.data || !Array.isArray(n.data.elements)) return;
          n.data.elements.forEach(function (el) {
            if (!el || el.type !== TYPE) return;
            var d = el.data || {};
            var where = 'The 3D model "' + el.id + '" on "' + (n.data.title || n.id) + '"';
            if (!d.model) found.push({ code: RULE, severity: 'warning', nodeId: n.id, message: where + ' has no model chosen.' });
            else if (!have[d.model]) found.push({ code: RULE, severity: 'warning', nodeId: n.id, message: where + ' uses a file that is not in the course.' });
            if (!(typeof d.description === 'string' && d.description.trim())) found.push({ code: RULE, severity: 'warning', nodeId: n.id, message: where + ' has no description for screen readers. Describe what it shows in Properties.' });
          });
        });
        return found;
      }
    });
  }
}]);
