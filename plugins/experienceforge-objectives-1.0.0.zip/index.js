// Objectives: what a learner should be able to do, kept with the course and linked to the quiz questions that test it.
// It needs no permissions. It adds: a list of objectives (Build > Course lists), a "This question tests these objectives" field on every question,
// a Check course rule (an objective no question tests, and a quiz that asks for more from an objective than it has),
// a way for a quiz to ask a set number of questions from each objective, and a results look that charts how the learner did on each objective.
window.kfPlugins = (window.kfPlugins || []).concat([{
  manifest: { id: 'experienceforge.objectives', name: 'Objectives', version: '1.0.0', apiVersion: 1 },
  activate: function (api) {
    var LIST = 'experienceforge.objectives';
    var FIELD = 'experienceforge.objectives';
    var RULE = 'experienceforge.by-objective';

    function nameOf(row) {
      var t = typeof row.values.text === 'string' ? row.values.text.trim() : '';
      return t || 'Objective (no wording yet)';
    }
    function linked(ext) {
      var v = ext && ext[FIELD];
      return Array.isArray(v) ? v : [];
    }
    function shuffle(items, random) {
      for (var i = items.length - 1; i > 0; i--) {
        var j = Math.min(i, Math.floor(random() * (i + 1)));
        var t = items[i]; items[i] = items[j]; items[j] = t;
      }
      return items;
    }

    api.data.addList({
      id: LIST,
      label: 'Objectives',
      itemLabel: 'Objective',
      help: 'What a learner should be able to do. Link each quiz question to the objectives it tests, on the question itself.',
      maxRows: 60,
      fields: [
        { kind: 'text', key: 'text', label: 'The objective', default: '', maxLength: 200, multiline: true, help: 'Start with what the learner will do, such as "Spot a fake sender address".' },
        { kind: 'text', key: 'section', label: 'Section (optional)', default: '', maxLength: 60, help: 'The part of the course it belongs to, if you want to keep them apart.' }
      ]
    });

    api.quiz.addQuestionField({
      id: FIELD,
      label: 'This question tests these objectives',
      help: 'Tick every objective this question tests. Add objectives under Build, Course lists.',
      setting: { kind: 'multi', fromList: LIST, max: 10 }
    });

    api.quiz.addDrawRule({
      id: RULE,
      label: 'A set number from each objective',
      description: 'Takes the same number of questions from each objective in turn, so none is left out. A question that tests several counts toward the first it is chosen for.',
      settings: [
        { kind: 'number', key: 'each', label: 'Questions from each objective', default: 2, min: 1, max: 20 },
        { kind: 'boolean', key: 'fill', label: 'If an objective has too few questions, make up the number with others', default: true }
      ],
      draw: function (ctx) {
        var objectives = ctx.list(LIST);
        var each = ctx.settings.each;
        var limit = ctx.count > 0 ? ctx.count : Infinity;
        var chosen = [];
        var taken = {};
        // each objective's questions, shuffled once
        var queues = objectives.map(function (o) {
          return shuffle(ctx.pool.filter(function (q) { return linked(q.ext).indexOf(o.id) !== -1; }), ctx.random);
        });
        // round by round, so a limit smaller than every objective's share is still spread across them
        for (var round = 0; round < each && chosen.length < limit; round++) {
          for (var k = 0; k < queues.length && chosen.length < limit; k++) {
            var q = null;
            while (queues[k].length && !q) {
              var next = queues[k].shift();
              if (!taken[next.id]) q = next;
            }
            if (q) { taken[q.id] = true; chosen.push(q.id); }
          }
        }
        if (ctx.settings.fill && ctx.count > 0 && chosen.length < ctx.count) {
          var rest = shuffle(ctx.pool.filter(function (p) { return !taken[p.id]; }), ctx.random);
          for (var r = 0; r < rest.length && chosen.length < ctx.count; r++) chosen.push(rest[r].id);
        }
        return chosen;
      }
    });

    api.validation.addRule({
      id: RULE,
      label: 'Objectives are tested',
      check: function (project, ctx) {
        var found = [];
        var objectives = ctx.list(LIST);
        if (objectives.length === 0) return found;
        var counts = {};
        var anyLinked = false;
        var unlinked = 0;
        ctx.questions.forEach(function (q) {
          var ids = linked(q.ext);
          if (ids.length) anyLinked = true; else unlinked++;
          ids.forEach(function (id) { counts[id] = (counts[id] || 0) + 1; });
        });
        objectives.forEach(function (o) {
          if (!counts[o.id]) found.push({ code: RULE, severity: 'warning', message: 'The objective "' + nameOf(o) + '" is not tested by any question. Link at least one question to it, or take it out of the list.' });
        });
        if (anyLinked && unlinked > 0) {
          found.push({ code: RULE, severity: 'warning', message: unlinked + (unlinked === 1 ? ' question is' : ' questions are') + ' not linked to any objective, so they will not count in the results by objective.' });
        }
        // a quiz that takes a set number from each objective but has fewer than that for one of them
        (project.nodes || []).forEach(function (node) {
          if (node.type !== 'bankNode' || !node.data || node.data.drawRule !== RULE) return;
          var each = node.data.drawSettings && typeof node.data.drawSettings.each === 'number' ? node.data.drawSettings.each : 2;
          var cats = Array.isArray(node.data.categories) && node.data.categories.length ? node.data.categories : null;
          var pool = ctx.questions.filter(function (q) { return !cats || cats.indexOf(q.category) !== -1; });
          objectives.forEach(function (o) {
            var have = pool.filter(function (q) { return linked(q.ext).indexOf(o.id) !== -1; }).length;
            if (have < each) {
              found.push({ code: RULE, severity: 'warning', nodeId: node.id, message: 'The quiz "' + (node.data.title || node.id) + '" asks for ' + each + ' from each objective, but "' + nameOf(o) + '" has ' + have + ' question' + (have === 1 ? '' : 's') + ' in the categories it uses.' });
            }
          });
        });
        return found;
      }
    });

    api.quiz.addResultsLayout({
      id: RULE,
      label: 'Score and a chart by objective',
      render: function (ctx) {
        var doc = ctx.doc;
        var s = ctx.summary;
        var root = doc.createElement('div');
        var line = doc.createElement('p');
        line.textContent = 'You scored ' + s.percent + '%: ' + s.correct + ' of ' + s.asked + ' questions right. ' + (s.passed ? 'You passed.' : 'You did not reach the pass mark of ' + Math.round(s.passMark * 100) + '%.');
        root.appendChild(line);

        var rows = ctx.list(LIST).map(function (o) {
          var mine = ctx.answers.filter(function (a) { return linked(a.ext).indexOf(o.id) !== -1; });
          var right = mine.filter(function (a) { return a.correct; }).length;
          return { name: nameOf(o), total: mine.length, right: right, percent: mine.length ? Math.round((right / mine.length) * 100) : 0 };
        }).filter(function (r) { return r.total > 0; });
        if (rows.length === 0) return root;

        var threshold = Math.round(s.passMark * 100);
        var heading = doc.createElement('h3');
        heading.textContent = 'How you did on each objective';
        root.appendChild(heading);
        var list = doc.createElement('ul');
        list.style.cssText = 'list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px';
        rows.forEach(function (r) {
          var item = doc.createElement('li');
          var label = doc.createElement('div');
          label.textContent = r.name;
          label.style.fontWeight = '600';
          var bar = doc.createElement('progress');
          bar.max = r.total;
          bar.value = r.right;
          bar.style.cssText = 'width:100%;height:18px';
          bar.setAttribute('aria-label', r.name + ': ' + r.right + ' of ' + r.total + ' right');
          var words = doc.createElement('div');
          words.textContent = r.right + ' of ' + r.total + ' right (' + r.percent + '%)' + (r.percent < threshold ? '. Needs more practice.' : '. Solid.');
          item.appendChild(label);
          item.appendChild(bar);
          item.appendChild(words);
          list.appendChild(item);
        });
        root.appendChild(list);

        var weak = rows.filter(function (r) { return r.percent < threshold; }).sort(function (a, b) { return a.percent - b.percent; });
        var next = doc.createElement('p');
        next.textContent = weak.length
          ? 'Work on next: ' + weak.map(function (r) { return r.name; }).join('; ') + '.'
          : 'You reached the pass mark on every objective.';
        root.appendChild(next);
        return root;
      }
    });
  }
}]);
