## Objectives: link quiz questions to what they test
**Objectives** is a plugin. Install it from a file under **Help → Plugins…**, then tick **Use in this course**. It lets you write down what a learner should be able to do, link each quiz question to the objectives it tests, and show the learner how they did on each one.

1. **Write the objectives.** Choose **Build → Objectives…**, then **Add an objective** for each one. Start with what the learner will do, such as "Spot a fake sender address". The section box is optional.

![The Objectives list dialog with three objectives, each with a box for the wording and an optional section, and Up, Down and Remove buttons](images/objectives-list.png)

2. **Link each question.** In the question editor (a Question step's properties, or the question bank), tick the objectives under **This question tests these objectives**. A question can test several. A question you leave unticked simply is not part of the chart.

![A question in the question bank with the group of check boxes "This question tests these objectives", one of three ticked](images/objectives-question.png)

3. **Check that all are tested.** **Check course** warns when an objective has no question, and when some questions are linked and others are not.

4. **Shape a quiz by objective (optional).** On a Quiz step, under **How the questions are chosen**, pick **A set number from each objective** and say how many to take from each. It takes one question from each objective in turn, so even a small quiz covers them all. Check course warns if an objective has fewer questions than you asked for.

![A Quiz step with How the questions are chosen set to A set number from each objective, and the number from each objective and the make-up option below it](images/objectives-quiz-rule.png)

5. **Show the learner where to work.** On a Results page, choose **Score and a chart by objective** under **Results page layout**. The learner sees their score, then a bar for each objective with the count in words, and a line saying which to work on next.

![The results page: the score line, then a bar for each objective with how many were right and whether it needs more practice, and a Work on next line](images/objectives-results.png)

The chart is plain text and native bars, so it works with a screen reader. Objectives that were not asked this time are left out.
