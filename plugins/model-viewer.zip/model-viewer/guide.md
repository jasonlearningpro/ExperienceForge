## 3D model viewer: show a 3D model on a screen
**3D model viewer** is a plugin. Install it from a file under **Help → Plugins…**, then tick **Use in this course**. It puts a 3D model on a screen, such as a machine part or a character, that the learner can turn around to see from every side. You place and size it like any other item.

1. **Get a model file.** In Blender, choose **File → Export → glTF 2.0**, set **Format** to **glTF Binary (.glb)**, and leave compression off. An **.stl** file also works, but it has no colors of its own, so you choose one. A file can be up to 20 MB. The plugin shows the shapes, their colors and where each part sits; it does not show pictures wrapped on a model (textures), animation or lights.

2. **Bring it in.** Open the **Assets** tab and choose **Import 3D model…**. The app checks the file by what is in it, and says in words what is wrong if it cannot be used, such as a model that was saved with compression.

![The Assets tab with the Import 3D model button, and a file called monkey.glb listed with the size 32 KB](images/model-viewer-assets.png)

3. **Put it on a screen.** Select a screen, choose **＋ More** above the stage, then **3D model**. Drag it and resize it with the handles like any item.

4. **Choose the model and its look.** In **Properties**, pick the file under **3D model**. Type a **Description for screen readers**, such as "A monkey head on a round stand": a learner who cannot see the picture is told this. **Check course** warns when it is missing. **Starting turn** and **Starting tilt** set the angle the learner first sees. **Color** is used for a model with no color of its own, such as an STL.

![The Properties of a 3D model: the file monkey.glb, the description, the color and the starting turn](images/model-viewer-properties.png)

5. **Decide what the learner can do.** **The learner can turn it by dragging** lets them drag with a mouse or finger. **Show buttons to turn, tilt and zoom** adds a row of buttons under the model. Turn both on, so nobody depends on dragging alone. With the model selected in the course, the arrow keys also turn it, the plus and minus keys zoom, and Home goes back to the start. Nothing moves by itself.

![The 3D model on a screen in the preview: a monkey head on a round stand, with the buttons Turn left, Turn right, Tilt up, Tilt down, Zoom in, Zoom out and Reset under it](images/model-viewer-stage.png)

**Good to know**
- The model is drawn with the learner's own graphics. A device that cannot draw 3D shows a message instead. The description is still read out.
- On a phone the model keeps its shape inside its box. Small widths from **Width on a phone** work like any item.
- A model makes the course bigger: its whole file goes in the course. Keep it as light as you can.
- An STL is drawn with Z as up, as most design programs make it, and in the color you chose.
- **Starting turn** and **Starting tilt** are in degrees.
