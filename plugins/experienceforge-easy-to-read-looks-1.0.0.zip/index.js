// Easy-to-read looks: large-print player looks, extra-large captions with strong contrast, and an easy-to-read font.
// Every color pair here has a contrast ratio of at least 7:1 (WCAG 2.1 level AAA for text, so level AA is met with room to spare).
// It needs no permissions.
window.kfPlugins = (window.kfPlugins || []).concat([{
  manifest: { id: 'experienceforge.easy-to-read-looks', name: 'Easy-to-read looks', version: '1.0.0', apiVersion: 1 },
  activate: function (api) {
    // Player looks. The buttons are the largest size the player allows (72 px), square-cornered, and the bar is docked.
    api.player.addPreset({
      id: 'experienceforge.large-print-light',
      label: 'Large print, light',
      look: { accent: '#0b3d91', barBackground: '#ffffff', barText: '#000000', pageBackground: '#ffffff', radius: 8, buttonSize: 72, buttonStyle: 'square', barStyle: 'docked', barPosition: 'bottom' }
    });
    api.player.addPreset({
      id: 'experienceforge.large-print-dark',
      label: 'Large print, dark',
      look: { accent: '#ffd400', barBackground: '#000000', barText: '#ffffff', pageBackground: '#000000', radius: 8, buttonSize: 72, buttonStyle: 'square', barStyle: 'docked', barPosition: 'bottom' }
    });

    // Caption styles. The size is in the same units as the styles that come with the app (28 is standard, 40 is large).
    api.audio.addCaptionStyle({ id: 'experienceforge.extra-large', label: 'Extra large, white on black', fontSize: 52, color: '#ffffff', background: '#000000' });
    api.audio.addCaptionStyle({ id: 'experienceforge.extra-large-yellow', label: 'Extra large, yellow on black', fontSize: 52, color: '#ffeb3b', background: '#000000' });
    api.audio.addCaptionStyle({ id: 'experienceforge.large-dark-on-light', label: 'Large, black on white', fontSize: 46, color: '#000000', background: '#ffffff' });

    // A font choice. Atkinson Hyperlegible is used if it is installed on the learner's computer; otherwise Verdana, then Tahoma.
    // No font file is shipped, so the look depends on what the computer has. These faces are widely recommended for easy reading.
    api.theme.addFont({ label: 'Easy to read (Atkinson Hyperlegible, Verdana)', value: "'Atkinson Hyperlegible', Verdana, Tahoma, sans-serif" });
  }
}]);
