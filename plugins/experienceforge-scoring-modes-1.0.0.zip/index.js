// Scoring modes: two ways of turning a learner's answers into a score. Pick one under "How the score is worked out" on a Results page.
// They need no permissions. Each answer carries its points and how many points the question was worth (`possible`), plus
// `attempt` (which try it was recorded on, from 1) and `share` (how much of it was right, from 0 to 1). Progress saved by an
// earlier version of the app has neither, so those answers are scored the way the standard mode would score them.
window.kfPlugins = (window.kfPlugins || []).concat([{
  manifest: { id: 'experienceforge.scoring-modes', name: 'Scoring modes', version: '1.0.0', apiVersion: 1 },
  activate: function (api) {
    function total(answers, points) {
      var sum = 0;
      var possible = 0;
      answers.forEach(function (a) {
        possible += a.possible;
        sum += Math.min(a.possible, Math.max(0, points(a)));
      });
      return { points: sum, possible: possible };
    }

    api.quiz.addScoring({
      id: 'experienceforge.first-try',
      label: 'Right on the first try',
      description: 'A question earns its points only if the learner got it right on the first try. A right answer on a later try earns nothing.',
      score: function (answers) {
        return total(answers, function (a) {
          if (typeof a.attempt !== 'number') return a.points; // saved by an earlier version: score as the standard mode does
          return a.correct && a.attempt === 1 ? a.possible : 0;
        });
      }
    });

    api.quiz.addScoring({
      id: 'experienceforge.partial-credit',
      label: 'Partial credit',
      description: 'A question with several right choices earns a share of its points for each right choice picked, minus a share for each wrong one. Other questions are all or nothing.',
      score: function (answers) {
        return total(answers, function (a) {
          if (typeof a.share !== 'number') return a.points; // saved by an earlier version: score as the standard mode does
          return a.possible * a.share;
        });
      }
    });
  }
}]);
