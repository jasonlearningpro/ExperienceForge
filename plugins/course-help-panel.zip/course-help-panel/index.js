// Course help panel: a Help button in the player's control bar that opens a side panel listing the keys that work and how
// to turn captions on and off. It needs no permissions. Everything it shows is plain text.
window.kfPlugins = (window.kfPlugins || []).concat([{
  manifest: { id: 'experienceforge.course-help-panel', name: 'Course help panel', version: '1.0.0', apiVersion: 1 },
  activate: function (api) {
    function section(doc, heading, rows) {
      var wrap = doc.createElement('section');
      var h = doc.createElement('h3');
      h.textContent = heading;
      h.style.cssText = 'margin:16px 0 6px;font-size:1.05em';
      var list = doc.createElement('dl');
      list.style.cssText = 'margin:0';
      rows.forEach(function (row) {
        var dt = doc.createElement('dt');
        dt.textContent = row[0];
        dt.style.cssText = 'font-weight:700;margin-top:8px';
        var dd = doc.createElement('dd');
        dd.textContent = row[1];
        dd.style.cssText = 'margin:2px 0 0';
        list.append(dt, dd);
      });
      wrap.append(h, list);
      return wrap;
    }

    api.player.addPanel({
      id: 'experienceforge.help',
      title: 'Help',
      icon: '?',
      side: 'right',
      render: function (ctx) {
        var doc = ctx.doc;
        var box = doc.createElement('div');
        box.style.cssText = 'padding:4px 16px 16px;line-height:1.5';

        var intro = doc.createElement('p');
        intro.textContent = 'You can use this course with the keyboard alone. Some buttons below only appear when the course has them.';
        box.append(intro);

        box.append(section(doc, 'Keyboard', [
          ['Tab and Shift+Tab', 'Move to the next or previous button or link.'],
          ['Enter or Space', 'Press the button you are on. Space also ticks or unticks an answer box.'],
          ['Arrow keys', 'In a question with round answer buttons (one right answer), move between the choices.'],
          ['Escape', 'Close a menu, this panel, or a pop-up.'],
          ['Ctrl and plus, Ctrl and minus', 'Make the whole page larger or smaller. Ctrl and 0 puts it back.']
        ]));

        box.append(section(doc, 'Captions', [
          ['Turn captions on or off', 'Press the Captions button in the control bar at the edge of the screen. Its name changes to Turn captions off or Turn captions on, and a screen reader announces whether it is on.'],
          ['No Captions button?', 'The screen you are on has no sound, so there is nothing to caption.']
        ]));

        box.append(section(doc, 'Control bar', [
          ['Back and Next', 'Go to the previous or next screen.'],
          ['Play and Pause, Replay', 'Start, stop or restart the narration and motion on this screen.'],
          ['Speed and Volume', 'Change how fast it plays, or mute it.'],
          ['Contents or Menu', 'See all the screens. If the course allows it, jump to one you have already visited.'],
          ['Full screen', 'Fill the whole display. Press Escape to leave.']
        ]));

        var where = doc.createElement('p');
        where.style.marginTop = '16px';
        where.textContent = ctx.page && ctx.page.title ? 'You are on: ' + ctx.page.title + '.' : '';
        if (where.textContent) box.append(where);
        return box;
      }
    });
  }
}]);
